# sharppcap
Fully managed, cross platform (Windows, Mac, Linux) .NET library for capturing packets

The official SharpPcap repository, moved from Sourceforge.
